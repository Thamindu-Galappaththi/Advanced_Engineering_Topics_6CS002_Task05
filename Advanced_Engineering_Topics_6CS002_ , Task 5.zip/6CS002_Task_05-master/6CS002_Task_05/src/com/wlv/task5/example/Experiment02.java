package com.wlv.task5.example;

public class Experiment02 {
	
public static void main(String[] args) {
	String[] n1= {"Science", "Mathematics", "History"};
	
	
	for (String subject:n1) {
		System.out.println(subject);
	}
}
}
